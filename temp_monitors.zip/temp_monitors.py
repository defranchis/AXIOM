import matplotlib.pyplot as plt
import numpy as np
from matplotlib.animation import FuncAnimation
import matplotlib.lines
import mpld3
from ke2001 import *
from sympy import Symbol
from sympy.solvers import solve

#matplotlib.use("Qt4agg")
plt.style.use('ggplot')
pause_time = 0.001


def mypause(interval):
    backend = plt.rcParams['backend']
    if backend in matplotlib.rcsetup.interactive_bk:
        figManager = matplotlib._pylab_helpers.Gcf.get_active()
        if figManager is not None:
            canvas = figManager.canvas
            if canvas.figure.stale:
                canvas.draw()
            canvas.start_event_loop(interval)
            return


def init_liveplot():
    plt.ion()
    fig = plt.figure(figsize=(15,5))
    ax0 = fig.add_subplot(131)
    ax1 = fig.add_subplot(132)
    ax2 = fig.add_subplot(133)

    return fig, ax0, ax1, ax2

def live_plotter(x_vec, y_vec, ax, line, identifier='', color='k',pause_time=0.001,title='',whichSignal=''):
    if line ==[]:
        if whichSignal == 'internal':
            line, = ax.plot(x_vec, y_vec, color='green', alpha=0.8,label = 'internal')
            ax.legend(loc='lower center')
        elif whichSignal == 'external':
            line, = ax.plot(x_vec, y_vec, color='orange', alpha=0.8, label = 'external')
            ax.legend(loc='lower center')
        elif whichSignal == 'setpoint':
            line, = ax.plot(x_vec, y_vec, color='yellow', alpha=0.8, label = 'setpoint')
            ax.legend(loc='lower center')
        else:
            line, = ax.plot(x_vec, y_vec, color='blue', alpha=0.8, label = 'pt_1000')
            ax.legend(loc='lower center')
        #update plot label/title
        ax.set_ylabel('Temperature (Celsius)')
        ax.set_xlabel('time (seconds)')
        ax.set_title(title)
        plt.show(block=False)

    line.set_xdata(x_vec)
    line.set_ydata(y_vec)
    ax.set_xlim([x_vec.min(),x_vec.max()])
    ax.set_ylim([0,25])
    
    # adjust limits if new data goes beyond bounds
    '''
    if np.min(y_vec)<=line.axes.get_ylim()[0] or np.max(y_vec)>=line.axes.get_ylim()[1]:
        ax.set_ylim([np.min(y_vec)-np.std(y_vec),np.max(y_vec)+np.std(y_vec)])
    '''
    '''
    if np.min(x_vec)<=line.axes.get_xlim()[0] or np.max(x_vec)>=line.axes.get_xlim()[1]:
        ax.set_xlim([np.min(x_vec)-np.std(x_vec),np.max(x_vec)+np.std(x_vec)])
    '''
    # this pauses the data so the figure/axis can catch up - the amount of pause can be altered above
    
    #plt.pause(pause_time)
    return line

# orange external green internal



def R2T_PTX_ITS90(R,R0):
    #PTX (X=R0) calibration with ITS-90 standard
    t = Symbol('t')
    A = 3.9083E-3
    B = -5.7750E-7
    C = 0.
    if R > R0 : C = -4.183E-12
    T = solve(R-R0*(1+A*t+B*t*t+C*(t-100)*t*t*t),t)
    return T[0]




from softcheck.logic import Com
from softcheck.logic import CommunicationTimeout
from softcheck.pp_commands import PpCom
import time
com = Com("serial", 2.1,3)
com.open("COM4", 9600) #open COM1 with 9600 (address not defined)
pp = PpCom(com)

x = np.array([])
maximumStepsBefore = 120
y = np.array([])
y2 = np.array([])
y3 = np.array([])
y4 = np.array([])
line  = []
line2 = []
line3 = []
line4 = []
fig = plt.figure(figsize=(10,5))
ax = fig.add_subplot(111)
ax2 = fig.add_subplot(111)
ax3 = fig.add_subplot(111)
ax4 = fig.add_subplot(111)
multimeter = ke2001(16)
multimeter.reset()
multimeter.set_sense('resistance')
multimeter.set_terminal('rear')
multimeter.set_nplc(10)

i = 0
plt.ion()
toggle_var = True

'''
com.send('SP@+2000\r\ni')
com.send('TM@+0001\r\n')
com.send('SP?\r\n')
com.recv()
com.send('TM?\r\n')
com.recv()
time.sleep(3)
com.send('CA@+0001\r\n')
com.send('CA?\r\n')
com.recv()
time.sleep(3)
'''
initialTimeSec = time.time()
while (True):
    R = float(multimeter.read_resistance().split(',')[0].replace('OHM','').replace('N',''))
    pt1000_temp = R2T_PTX_ITS90(R,1000)
    internal_temp = pp.request_echo("TI")
    external_temp = pp.request_echo("TE")
    setpoint_temp = pp.request_echo('SP')
    
    if (i % maximumStepsBefore) == 0:
        if toggle_var:
            toggle_var = False
            #pp.send("SP",2000)
        else:
            toggle_var = True
            #pp.send('SP',1600)
    
    if i < (maximumStepsBefore + 2):
        x = np.concatenate((x,np.array([time.time() - initialTimeSec])))
        y = np.concatenate((y,np.array([internal_temp/100])))
        y2 = np.concatenate((y2,np.array([external_temp/100])))
        y3 = np.concatenate((y3,np.array([setpoint_temp/100])))
        y4 = np.concatenate((y4,np.array([pt1000_temp])))
    else:
        x = np.concatenate((x,np.array([time.time() - initialTimeSec])))
        x = x[1:]
        y = np.concatenate((y,np.array([internal_temp/100])))
        y = y[1:]
        y2 = np.concatenate((y2,np.array([external_temp/100])))
        y2 = y2[1:] 
        y3 = np.concatenate((y3,np.array([setpoint_temp/100])))
        y3 = y3[1:]
        y4 = np.concatenate((y4,np.array([pt1000_temp])))
        y4 = y4[1:]
    line = live_plotter(x,y,ax,line,pause_time=pause_time,title='Thermal Monitors',whichSignal='internal')
    line2 = live_plotter(x,y2,ax2,line2,pause_time=pause_time,title='Thermal Monitors',whichSignal='external')
    line3 = live_plotter(x,y3,ax3,line3,pause_time=pause_time,title='Thermal Monitors',whichSignal='setpoint')
    line4 = live_plotter(x,y4,ax4,line4,pause_time=pause_time,title='Thermal Monitors',whichSignal='pt_1000')
    mypause(1)
    i+=2   
#com.send('CA@+0000\r\n')

#pp.request("TI")
##pp.check_range("TI", 500, 6000)
##pp.request("TE")
##pp.check_range("TE", 0, 7000)
#p.change_to("CA", 1)
#time.sleep(20)
##pp.request("TP")
#pp.send("SP",  1000)
#
### to get the internal temperature:
#print('this is the internal temperature')
#p.request_echo("TI")
#print('this is the setpoint .... maybe')
#p.request_echo("SP")
#print('this is the external temperature')
#p.request_echo("TE")
#com.close()
